package com.sgturnos.service;

public class RegistroService {
    
}